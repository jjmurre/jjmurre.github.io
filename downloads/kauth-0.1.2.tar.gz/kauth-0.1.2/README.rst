KNMP Authorization cli

Simple cli app to maintain the knmp_authorization tabel with applications, users and roles.


INSTALL
=======

::

    $ pip install tarball.tgz

USAGE
=====

Self-documenting cli interface.

