import os
import sys
from ConfigParser import SafeConfigParser, NoSectionError
import argh
from argh.interaction import confirm
from sqlalchemy import create_engine
from knmp.sqlalchemy.auth import Application, Role, User
from sqlalchemy.orm import sessionmaker


def _wc(s):
    return s.replace('*', '%')


def fetch_session():
    config = SafeConfigParser()
    try:
        config.read([os.path.expanduser('~/.kauth.cfg')])
        connection = config.get('database', 'connection')
    except NoSectionError:
        print "Add a 'kauth.cfg' to your home directory."
        sys.exit()
    else:
        engine = create_engine(connection, echo=False)
        Session = sessionmaker(bind=engine)
        return Session()


def listapps():
    session = fetch_session()
    return [a.name for a in session.query(Application)]


def listusers():
    session = fetch_session()
    return ["{0} ({1})".format(u.name, u.id) for u in session.query(User)]


def listroles(appname=None):
    session = fetch_session()
    roles = session.query(Role)
    if appname is not None:
        roles = roles.filter(Role.application.has(Application.name.ilike(_wc(appname))))
    return ["{0} for {1}".format(r.name, r.application.name) for r in roles]


def listuserroles(username):
    session = fetch_session()
    users = session.query(User).filter(User.name.ilike(_wc(username)))

    result = []
    for user in users:
        result.append("User: {0}".format(user.name))
        result.append("Roles:")
        result.extend(["{0}: {1}".format(r.application.name, r.name) for r in user.roles])
    return result


def adduser(username):
    session = fetch_session()
    users = session.query(User).filter(User.name == username)
    if users.count() > 0:
        return "User exists: {0}".format(','.join(u.name for u in users))
    user = User(name=username)
    session.add(user)
    session.commit()
    return "Added user: {0}".format(username)

def addapp(appname):
    session = fetch_session()
    apps = session.query(Application).filter(Application.name == appname)
    if apps.count() > 0:
        return "Application exists: {0}".format(','.join(a.name for a in apps))
    app = Application(name=appname)
    session.add(app)
    session.commit()
    return "Added app: {0}".format(appname)


def addrole(rolename, appname=''):
    session = fetch_session()
    apps = session.query(Application).filter(Application.name.ilike(_wc(appname)))
    appnames = ", ".join(a.name for a in apps)
    if confirm("About to add role '{0}' for application(s): {1}".format(
                        rolename, appnames)):
        for app in apps:
            role = Role(name=rolename, application=app)
            session.add(role)
        session.commit()
        return "Added role {0} for application(s): {1}".format(rolename, appnames)
    else:
        return "aborted"


def adduserrole(rolename, appname='', username=''):
    session = fetch_session()
    users = session.query(User).filter(User.name.ilike(_wc(username)))
    apps = session.query(Application).filter(Application.name.ilike(_wc(appname)))
    usernames = ", ".join(u.name for u in users)
    appnames = ", ".join(a.name for a in apps)
    if confirm("About to add role '{0}' for user(s): {1} and application(s): {2}".format(
                        rolename, usernames, appnames)):

        for app in apps:
            roles = session.query(Role).join(Application).filter(
                Role.name == rolename).filter(Application.id == app.id)
            if roles:
                role = roles[0]
            else:
                role = Role(name=rolename, application=app)
            role.users.extend(users)
            session.add(role)
        session.commit()
        return "Added role {0} for user(s): {1} and application(s): {2}".format(rolename, usernames, appnames)
    else:
        return "aborted"


def removeuserrole(rolename, appname='', username=''):
    session = fetch_session()
    users = session.query(User).filter(User.name.ilike(_wc(username)))
    apps = session.query(Application).filter(Application.name.ilike(_wc(appname)))
    usernames = ", ".join(u.name for u in users)
    appnames = ", ".join(a.name for a in apps)
    if confirm("About to remove role '{0}' for user(s): {1} and application(s): {2}".format(
                        rolename, usernames, appnames)):

        for app in apps:
            roles = session.query(Role).join(Application).filter(
                Role.name == rolename).filter(Application.id == app.id)
            for user in users:
                for role in roles:
                    user.roles.remove(role)
                session.add(user)
        session.commit()
        return "Removed role {0} for user(s): {1} and application(s): {2}".format(rolename, usernames, appnames)
    else:
        return "aborted"


def main():
    argh.dispatch_commands([listapps, listusers, listroles, listuserroles,
        adduser, addapp, addrole, adduserrole, removeuserrole])

    # XXX tbd. removeapp, removerole, removeuser: how about cascading?
    # Cascade: remove app -> associated roles
    # remove user: associations with role through user_role
    # remove role -> associations with user through user_role
