from fabric.api import local, settings, abort, lcd
from fabric.contrib.console import confirm
from fabric.state import env
import datetime
import sys


env.project = "kauth"
env.today = datetime.datetime.now().strftime('%Y%m%d')
env.now = datetime.datetime.now().strftime('%Y%m%d-%H%M')


def export_head():
    """ Make tarball of head.
    """
    local("git archive --format=tar --prefix={project}-{today}/ HEAD | "
    "gzip > /tmp/{project}-{today}.tgz".format(**env))
